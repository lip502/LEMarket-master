package com.dao.test;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.phonemarket.entity.GoodsType;
import com.phonemarket.mapper.GoodsTypeMapper;
import com.phonemarket.mapper.GuessMapper;
import com.phonemarket.mapper.OrderMapper;

public class DaoTest {

	@Test
	public void test() {
		/*ApplicationContext app=new ClassPathXmlApplicationContext("applicationContext.xml");
		GoodsTypeMapper dao = app.getBean(GoodsTypeMapper.class);
		Integer rs = dao.changeTypeState(1, 1);
		System.out.println(rs);*/
	}

}
