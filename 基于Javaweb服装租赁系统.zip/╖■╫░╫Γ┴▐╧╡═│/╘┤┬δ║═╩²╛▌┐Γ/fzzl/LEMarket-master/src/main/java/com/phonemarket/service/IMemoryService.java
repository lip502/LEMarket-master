package com.phonemarket.service;

import java.util.List;

import com.phonemarket.entity.Memory;

public interface IMemoryService {
	List<Memory> finAllMemory();
}
